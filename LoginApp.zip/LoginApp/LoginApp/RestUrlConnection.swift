//
//  RestUrlConnection.swift
//  LoginApp
//
//  Created by Jabeed on 07/08/19.
//  Copyright © 2019 Jabeed. All rights reserved.
//

import UIKit

class RestUrlConnection: NSURLConnection,URLSessionDelegate {
  
  class  func getNetworkResponseFromServer(apiName:NSString,params:NSMutableDictionary,callbackHandler:((NSError?, NSMutableDictionary?) -> Void)!) {
    let urlString = String(format:"https://papa.fit/routes/registrationRoute.php?action=%@",apiName)
    let query  = urlString.addingPercentEncoding(withAllowedCharacters: CharacterSet.urlQueryAllowed)
    var request = URLRequest(url:URL(string:query!)!)
    request.timeoutInterval = 180
    request.httpMethod = "POST"
    request.addValue("application/json", forHTTPHeaderField: "Content-Type")
    do {
      let jsonData = try JSONSerialization.data(withJSONObject: params, options: JSONSerialization.WritingOptions.prettyPrinted)
      request.httpBody = jsonData
      let configuration = URLSessionConfiguration.default
      let session = URLSession(configuration: configuration, delegate: RestUrlConnection(),
                               delegateQueue: OperationQueue.main)
      let task = session.dataTask(with: request, completionHandler: { (data, response, error) in
        if let respone = data {
          do {
            let json = try JSONSerialization.jsonObject(with:respone, options: [])
            let jsonDictionary = NSMutableDictionary(dictionary: json as! NSDictionary)
            callbackHandler(nil,jsonDictionary)
          } catch let error as NSError {
            callbackHandler(error, nil)
          }
        }else{
          callbackHandler(error! as NSError, nil)
        }
      })
      task.resume()
      
    } catch {
      
    }
    
  }
  
  
  func urlSession(_ session: URLSession, didReceive challenge: URLAuthenticationChallenge, completionHandler: @escaping (URLSession.AuthChallengeDisposition, URLCredential?) -> Void) {
    completionHandler(URLSession.AuthChallengeDisposition.useCredential, URLCredential(trust: challenge.protectionSpace.serverTrust!))
  }
    
    
    
    
    
}

